import React from 'react'

function Error() {
  return (
    <div className='h-screen bg-gradient-to-r from-cyan-500 to-blue-500 flex justify-center'>
        <img src="../../img/notfound.png" alt="notfoun" />
    </div>
  )
}

export default Error